<?php
/**
 * @package Component codoPM for Joomla! 3.0
 * @author codologic
 * @copyright (C) 2013 - codologic
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

defined('_JEXEC') or die;
?>
<div>
    
    
    <blockquote >
        
        <b>You are not logged in . 
        Please login to use PMS
        </b>  
    </blockquote>
    
    
</div>
