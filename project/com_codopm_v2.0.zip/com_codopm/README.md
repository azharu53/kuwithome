								CODOPM


CODOPM is a simple and beautiful private messaging system developed for Joomla . 


Requirements:
PDO-MYSQL must be installed.


Installation:

1. Use the Joomla Installer to install this component. 

2. Add menu link by adding menu item in the menu manager. 

Please provide any feedback or feature requests by emailing us at admin@codologic.com
