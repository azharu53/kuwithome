<?php

defined('_JEXEC') or die;

/**
 * @package Component codoPM for Joomla! 3.0
 * @author codologic
 * @copyright (C) 2013 - codologic
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * */


$codopm_trans['Compose'] = 'Compose';
$codopm_trans['Inbox'] = 'Inbox';
$codopm_trans['Reply'] = 'Reply';
$codopm_trans['Add files'] = 'Add files';
$codopm_trans['To'] = 'To';
$codopm_trans['Message'] = 'Message';
$codopm_trans['Attach files'] = 'Attach files';
$codopm_trans['Attached files'] = 'Attached files';
$codopm_trans['Send'] = 'Send';
$codopm_trans['Load older messages'] = 'Load older messages';
$codopm_trans['Top'] = 'top';
$codopm_trans['seconds ago'] = 'seconds ago';
$codopm_trans['just now'] = 'just now';
$codopm_trans['No messages found!'] = 'No messages found!';
$codopm_trans['Click to enter text to reply'] = 'Click to enter text to reply';