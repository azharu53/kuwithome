<?php

/**
 * @package Component codoPM for Joomla! 3.0
 * @author codologic
 * @copyright (C) 2013 - codologic
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

// no direct access

defined('_JEXEC') or die('Restricted access');



// Import Joomla! libraries

jimport('joomla.application.component.model');



class CodopmModelCodopm extends JModel {

    function __construct() {

		parent::__construct();

    }

}

?>
