DROP TABLE IF EXISTS `codopm_messages`;
DROP TABLE IF EXISTS `codopm_config`;
