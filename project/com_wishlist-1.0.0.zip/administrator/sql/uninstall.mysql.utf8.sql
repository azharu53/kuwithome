DROP TABLE IF EXISTS `#__wishlist`;
