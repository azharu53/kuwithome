DROP TABLE IF EXISTS `#__banner_images`;
