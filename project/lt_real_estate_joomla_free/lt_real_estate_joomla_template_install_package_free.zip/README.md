####Most Powerful Features:
- Modern Design  (2015 web trends inlcuded)
- Flexibility & Fully Responsive Template
- Font Awesome 4.3 ( over 510+ Icons) also for menu items
- MegaMenu Generator
- Off-Canvas Menu & MegaMenu
- Article Post Formats
- Desktop,  Mobile and Retina logo option
- Advanced Typography Options - Google Fonts with update button
- Layout Manager
- Bootstrap 3.2
- Cross-Browser Support
and much more.

